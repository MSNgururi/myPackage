# mypackage
This library was created as a mock exercise for creating python packages.